import { describe, expect, it } from 'vitest';

describe('vitest sanity', () => {
  it('loads the test runner', () => {
    expect(true).toBe(true);
  });
});
