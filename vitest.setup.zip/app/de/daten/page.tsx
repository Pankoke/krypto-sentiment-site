import DataPage from '../../[locale]/data/page';

export default function DatenDePage() {
  return <DataPage params={{ locale: 'de' }} />;
}
