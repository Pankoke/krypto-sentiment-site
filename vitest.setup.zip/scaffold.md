// FILE: schema/sentiment.schema.json
{ ...kompletter JSON-Inhalt... }

// FILE: lib/types.ts
export interface DailyCryptoSentiment { ... }
// (weitere Dateien im selben Format)
