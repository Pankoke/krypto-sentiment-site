import ContactPage from '../../[locale]/contact/page';

export default function KontaktDePage() {
  return <ContactPage params={{ locale: 'de' }} />;
}
