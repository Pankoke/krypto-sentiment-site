import LearnPage from '../../[locale]/learn/page';

export default function LernenDePage() {
  return <LearnPage params={{ locale: 'de' }} />;
}
