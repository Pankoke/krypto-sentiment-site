import AboutPage from '../../[locale]/about/page';

export default function UeberUnsDePage() {
  return <AboutPage params={{ locale: 'de' }} />;
}
