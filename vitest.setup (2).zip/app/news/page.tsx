import { redirect } from 'next/navigation';

export default function NewsPage() {
  redirect('/de/news');
}
