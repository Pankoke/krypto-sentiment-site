export type { SentimentTrend, SentimentBullet, SentimentItem, SentimentResponse } from 'lib/sentiment/types';
